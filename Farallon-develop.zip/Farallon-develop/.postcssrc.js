module.exports = {
    plugins: {
        autoprefixer: {}
    }
};