module.exports = {
    singleQuote: true,
    semi: true
}